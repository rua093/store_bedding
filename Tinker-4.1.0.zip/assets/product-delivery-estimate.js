(() => {
  const ROOT_SELECTOR = '[data-delivery-estimate]';
  const RANGE_SELECTOR = '[data-delivery-date-range]';
  const TIMELINE_SELECTOR = '[data-delivery-timeline]';
  const DYNAMIC_RENDER_ROOT_SELECTOR = '#quick-add-modal-content';
  const TIME_ZONE = 'America/New_York';

  const nyDateFormatter = new Intl.DateTimeFormat('en-US', {
    timeZone: TIME_ZONE,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  });

  const shortMonthFormatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'UTC',
    month: 'short',
  });

  const longMonthFormatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'UTC',
    month: 'long',
  });

  const getDeliveryWindow = (countryCode) => {
    const normalizedCountryCode = String(countryCode || '').toUpperCase();

    if (normalizedCountryCode === 'US' || normalizedCountryCode === 'CA') {
      return {
        minimumBusinessDays: 10,
        maximumBusinessDays: 17,
      };
    }

    return {
      minimumBusinessDays: 17,
      maximumBusinessDays: 24,
    };
  };

  const getTodayInNewYork = () => {
    const parts = nyDateFormatter.formatToParts(new Date());
    const read = (type) => Number(parts.find((part) => part.type === type)?.value || 0);

    return new Date(Date.UTC(read('year'), read('month') - 1, read('day'), 12));
  };

  const addBusinessDays = (date, businessDays) => {
    const result = new Date(date.getTime());
    let daysAdded = 0;

    while (daysAdded < businessDays) {
      result.setUTCDate(result.getUTCDate() + 1);
      const weekday = result.getUTCDay();

      if (weekday !== 0 && weekday !== 6) {
        daysAdded += 1;
      }
    }

    return result;
  };

  const formatShortDate = (date, includeYear = false) => {
    const month = shortMonthFormatter.format(date);
    const day = date.getUTCDate();

    if (includeYear) {
      return `${month} ${day}, ${date.getUTCFullYear()}`;
    }

    return `${month} ${day}`;
  };

  const formatLongDate = (date, includeYear = false) => {
    const month = longMonthFormatter.format(date);
    const day = date.getUTCDate();

    if (includeYear) {
      return `${month} ${day}, ${date.getUTCFullYear()}`;
    }

    return `${month} ${day}`;
  };

  const formatDateRange = (earliestDate, latestDate) => {
    const sameYear = earliestDate.getUTCFullYear() === latestDate.getUTCFullYear();
    const sameMonth = sameYear && earliestDate.getUTCMonth() === latestDate.getUTCMonth();

    if (sameMonth) {
      return `${shortMonthFormatter.format(earliestDate)} ${earliestDate.getUTCDate()}\u2013${latestDate.getUTCDate()}`;
    }

    if (sameYear) {
      return `${formatShortDate(earliestDate)} \u2013 ${formatShortDate(latestDate)}`;
    }

    return `${formatShortDate(earliestDate, true)} \u2013 ${formatShortDate(latestDate, true)}`;
  };

  const formatLongDateRange = (earliestDate, latestDate) => {
    const sameYear = earliestDate.getUTCFullYear() === latestDate.getUTCFullYear();
    const sameMonth = sameYear && earliestDate.getUTCMonth() === latestDate.getUTCMonth();

    if (sameMonth) {
      return `${longMonthFormatter.format(earliestDate)} ${earliestDate.getUTCDate()} \u2013 ${latestDate.getUTCDate()}`;
    }

    if (sameYear) {
      return `${formatLongDate(earliestDate)} \u2013 ${formatLongDate(latestDate)}`;
    }

    return `${formatLongDate(earliestDate, true)} \u2013 ${formatLongDate(latestDate, true)}`;
  };

  const formatAriaLabel = (earliestDate, latestDate) => {
    const sameYear = earliestDate.getUTCFullYear() === latestDate.getUTCFullYear();

    return `Estimated delivery between ${formatLongDate(earliestDate, !sameYear)} and ${formatLongDate(
      latestDate,
      !sameYear
    )}`;
  };

  const updateEstimate = (root) => {
    const rangeElement = root.querySelector(RANGE_SELECTOR);
    if (!rangeElement) return;

    const { minimumBusinessDays, maximumBusinessDays } = getDeliveryWindow(root.dataset.countryCode);
    const baseDate = getTodayInNewYork();
    const earliestDate = addBusinessDays(baseDate, minimumBusinessDays);
    const latestDate = addBusinessDays(baseDate, maximumBusinessDays);

    rangeElement.textContent = formatDateRange(earliestDate, latestDate);
    root.setAttribute('aria-label', formatAriaLabel(earliestDate, latestDate));
  };

  const updateTimeline = (root) => {
    const countryCode = root.dataset.countryCode;
    const { minimumBusinessDays, maximumBusinessDays } = getDeliveryWindow(countryCode);
    const baseDate = getTodayInNewYork();
    const orderDate = baseDate;
    const shipStartDate = addBusinessDays(baseDate, 2);
    const shipEndDate = addBusinessDays(baseDate, 5);
    const deliveryStartDate = addBusinessDays(baseDate, minimumBusinessDays);
    const deliveryEndDate = addBusinessDays(baseDate, maximumBusinessDays);

    const orderDateElement = root.querySelector('[data-delivery-stage-order-date]');
    const shipRangeElement = root.querySelector('[data-delivery-stage-ship-range]');
    const deliveryRangeElement = root.querySelector('[data-delivery-stage-delivery-range]');

    if (orderDateElement) {
      orderDateElement.textContent = formatLongDate(orderDate);
    }

    if (shipRangeElement) {
      shipRangeElement.textContent = formatLongDateRange(shipStartDate, shipEndDate);
    }

    if (deliveryRangeElement) {
      deliveryRangeElement.textContent = formatLongDateRange(deliveryStartDate, deliveryEndDate);
    }
  };

  const updateAll = (scope = document) => {
    const roots =
      scope instanceof Element && scope.matches(ROOT_SELECTOR)
        ? [scope]
        : Array.from(scope.querySelectorAll ? scope.querySelectorAll(ROOT_SELECTOR) : []);

    const timelines =
      scope instanceof Element && scope.matches(TIMELINE_SELECTOR)
        ? [scope]
        : Array.from(scope.querySelectorAll ? scope.querySelectorAll(TIMELINE_SELECTOR) : []);

    roots.forEach(updateEstimate);
    timelines.forEach(updateTimeline);
  };

  const queueUpdate = (() => {
    let scheduled = false;

    return (scope = document) => {
      if (scheduled) return;

      scheduled = true;
      window.requestAnimationFrame(() => {
        scheduled = false;
        updateAll(scope);
      });
    };
  })();

  const observeDynamicRenders = () => {
    // Quick Add is the only storefront region that injects delivery markup after
    // initial page load. Observing `document.body` also reacts to unrelated app
    // renders (reviews, chat, personalization) and can trigger costly subtree scans.
    const dynamicRenderRoot = document.querySelector(DYNAMIC_RENDER_ROOT_SELECTOR);
    if (!dynamicRenderRoot || dynamicRenderRoot.dataset.deliveryEstimateObserved === 'true') return;

    const observer = new MutationObserver((mutations) => {
      let shouldUpdate = false;

      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (
            node.matches(ROOT_SELECTOR) ||
            node.closest(ROOT_SELECTOR) ||
            node.querySelector(ROOT_SELECTOR)
          ) {
            shouldUpdate = true;
            break;
          }
        }

        if (shouldUpdate) break;
      }

      if (shouldUpdate) queueUpdate(dynamicRenderRoot);
    });

    observer.observe(dynamicRenderRoot, {
      childList: true,
      subtree: true,
    });

    dynamicRenderRoot.dataset.deliveryEstimateObserved = 'true';
  };

  const initializeDeliveryEstimates = (scope = document) => {
    updateAll(scope);
    observeDynamicRenders();
  };

  if (document.readyState === 'loading') {
    document.addEventListener(
      'DOMContentLoaded',
      () => {
        initializeDeliveryEstimates(document);
      },
      { once: true }
    );
  } else {
    initializeDeliveryEstimates(document);
  }

  document.addEventListener('shopify:section:load', (event) => {
    initializeDeliveryEstimates(event.target);
  });

  document.addEventListener('shopify:section:reorder', () => {
    queueUpdate(document);
  });
})();
